import { Component } from '@angular/core';

@Component({
  selector: 'app-aggiungi-cliente',
  templateUrl: './aggiungi-cliente.component.html',
  styleUrl: './aggiungi-cliente.component.css'
})
export class AggiungiClienteComponent {

}
