import { Component } from '@angular/core';

@Component({
  selector: 'app-prenotazioni-cliente',
  templateUrl: './prenotazioni-cliente.component.html',
  styleUrl: './prenotazioni-cliente.component.css'
})
export class PrenotazioniClienteComponent {

}
